# Riwayat percakapan proyek (JANGAN di-commit — berisi data klien)

Letakkan folder ini di dalam repo sebagai `riwayat-chat/` (sudah ada di .gitignore). Claude Code membaca file di sini
HANYA bila perlu — jangan dibaca seluruhnya (±4 MB, boros token). Cari dengan grep/pencarian kata kunci.

| File | Isi |
|---|---|
| 01_sesi_2026-11-09_v2_planogram.txt | Rebuild v2: planogram, template/custom report, Argon, dokumen library dihapus, IAM |
| 02_sesi_2026-11-11_v2.1-v2.10.txt | v2.1–v2.10: unggahan, Excel, sandbox & meteran, cadangan 429, batas biaya, sizing biaya, debugging log |
| 03_sesi_2026-11-11_v3.0-v3.5.2.md | Ringkasan kronologis v3.0–v3.5.2 + pekerjaan terbuka (mulai baca dari sini) |

Contoh cara bertanya ke Claude Code: "Cari di riwayat-chat bagaimana kita memutuskan format laporan TXT" atau
"Di riwayat-chat, apa kunci jawaban uji RFM SR1?"
